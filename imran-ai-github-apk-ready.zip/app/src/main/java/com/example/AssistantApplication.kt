package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.local.UserPreferences
import com.example.engine.ContactResolver
import com.example.engine.DeviceActionExecutor
import com.example.engine.GeminiClient
import com.example.engine.IntentParser
import com.example.engine.PhotoEditorEngine

class AssistantApplication : Application() {

    val database by lazy { AppDatabase.getDatabase(this) }
    val userPreferences by lazy { UserPreferences(this) }
    val contactResolver by lazy { ContactResolver(this) }
    val deviceActionExecutor by lazy { DeviceActionExecutor(this) }
    val intentParser by lazy { IntentParser(contactResolver) }
    val photoEditorEngine by lazy { PhotoEditorEngine(this) }

    val geminiClient by lazy {
        GeminiClient(
            apiKeyProvider = {
                val customKey = userPreferences.customGeminiApiKey
                if (customKey.isNotBlank()) customKey else BuildConfig.GEMINI_API_KEY
            }
        )
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    companion object {
        lateinit var instance: AssistantApplication
            private set
    }
}
