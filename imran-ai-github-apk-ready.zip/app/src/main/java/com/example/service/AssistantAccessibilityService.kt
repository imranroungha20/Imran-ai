package com.example.service

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import java.lang.ref.WeakReference

class AssistantAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInstance = WeakReference(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Privacy preserved: No logging or reading of user input or screen content
    }

    override fun onInterrupt() {
        // Service interrupted
    }

    override fun onDestroy() {
        super.onDestroy()
        if (serviceInstance?.get() == this) {
            serviceInstance = null
        }
    }

    companion object {
        private var serviceInstance: WeakReference<AssistantAccessibilityService>? = null

        val isServiceEnabled: Boolean
            get() = serviceInstance?.get() != null

        fun performHome(): Boolean {
            return serviceInstance?.get()?.performGlobalAction(GLOBAL_ACTION_HOME) ?: false
        }

        fun performBack(): Boolean {
            return serviceInstance?.get()?.performGlobalAction(GLOBAL_ACTION_BACK) ?: false
        }

        fun performRecentApps(): Boolean {
            return serviceInstance?.get()?.performGlobalAction(GLOBAL_ACTION_RECENTS) ?: false
        }

        fun performNotifications(): Boolean {
            return serviceInstance?.get()?.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) ?: false
        }

        fun performQuickSettings(): Boolean {
            return serviceInstance?.get()?.performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS) ?: false
        }

        fun performLockScreen(): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                serviceInstance?.get()?.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) ?: false
            } else {
                false
            }
        }
    }
}
