package com.example.ui.screens

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Contrast
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.FilterPreset
import com.example.engine.PhotoEditState
import com.example.engine.PhotoEditorEngine
import com.example.ui.theme.AccentTeal
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.PrimaryNeon
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoStudioScreen(
    editorEngine: PhotoEditorEngine,
    initialPrompt: String? = null,
    isListening: Boolean,
    onMicClick: () -> Unit,
    onSpeakFeedback: (String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var originalBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var editedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var editState by remember { mutableStateOf(PhotoEditState()) }
    var isProcessing by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var voiceInputText by remember { mutableStateOf("") }
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Presets, 1: Sliders, 2: Tools
    var isHoldingOriginal by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                isProcessing = true
                val loaded = editorEngine.loadBitmapFromUri(uri)
                if (loaded != null) {
                    originalBitmap = loaded
                    editState = PhotoEditState()
                    editedBitmap = loaded
                    statusMessage = "Photo load ho gayi hai, Boss! Batayein kaisa edit karna hai?"
                    onSpeakFeedback("Jee Boss, photo load ho gayi hai! Kaisa edit karna chahte hain?")
                }
                isProcessing = false
            }
        }
    }

    // Process edits whenever editState changes
    fun triggerEditProcessing(newState: PhotoEditState, feedback: String? = null) {
        val orig = originalBitmap ?: return
        scope.launch {
            isProcessing = true
            editState = newState
            val result = editorEngine.applyEdits(orig, newState)
            editedBitmap = result
            isProcessing = false
            if (!feedback.isNullOrBlank()) {
                statusMessage = feedback
                onSpeakFeedback(feedback)
            }
        }
    }

    fun applyVoiceInstruction(cmd: String) {
        if (originalBitmap == null) {
            statusMessage = "Boss, pehle koi photo select karein!"
            onSpeakFeedback("Boss, pehle gallery se photo select karein, phir main waise hi edit kar doonga!")
            return
        }

        val lower = cmd.lowercase()

        // Voice command: Save to gallery
        if (lower.contains("save") || lower.contains("gallery") || lower.contains("mehfooz")) {
            val bmp = editedBitmap ?: originalBitmap ?: return
            scope.launch {
                isProcessing = true
                val res = editorEngine.saveBitmapToGallery(bmp, "Imran_AI_Boss")
                res.onSuccess {
                    statusMessage = "Jee Boss, photo phone gallery mein save ho gayi hai!"
                    onSpeakFeedback("Jee Boss, photo aapki phone gallery mein save ho gayi hai!")
                }.onFailure { err ->
                    statusMessage = "Save error: ${err.message}"
                }
                isProcessing = false
            }
            return
        }

        // Voice command: Share
        if (lower.contains("share") || lower.contains("bhejo") || lower.contains("send")) {
            val bmp = editedBitmap ?: originalBitmap ?: return
            scope.launch {
                isProcessing = true
                val res = editorEngine.saveBitmapToGallery(bmp, "Imran_AI_Share")
                res.onSuccess { uri ->
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "image/jpeg"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Share Edited Photo"))
                    onSpeakFeedback("Jee Boss, photo share karne ke liye apps khol di hain!")
                }
                isProcessing = false
            }
            return
        }

        val (newState, feedback) = editorEngine.interpretVoiceEditCommand(cmd, editState)
        triggerEditProcessing(newState, feedback)
    }

    LaunchedEffect(initialPrompt) {
        if (!initialPrompt.isNullOrBlank()) {
            voiceInputText = initialPrompt
            if (originalBitmap != null) {
                applyVoiceInstruction(initialPrompt)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "AI Photo Studio",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = AccentTeal.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    "100% Free",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                                    color = AccentTeal,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            "Voice & AI Image Editor for Boss",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("photo_studio_back")) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (originalBitmap != null) {
                        IconButton(
                            onClick = {
                                editState = PhotoEditState()
                                editedBitmap = originalBitmap
                                onSpeakFeedback("Jee Boss, original photo restore kar di hai.")
                            },
                            modifier = Modifier.testTag("photo_reset_button")
                        ) {
                            Icon(imageVector = Icons.Default.RestartAlt, contentDescription = "Reset", tint = MaterialTheme.colorScheme.outline)
                        }

                        IconButton(
                            onClick = {
                                val bmp = editedBitmap ?: return@IconButton
                                scope.launch {
                                    isProcessing = true
                                    val res = editorEngine.saveBitmapToGallery(bmp, "Imran_AI_Boss")
                                    res.onSuccess { uri ->
                                        statusMessage = "Photo Gallery mein save ho gayi hai, Boss!"
                                        onSpeakFeedback("Jee Boss! Photo aapke phone ki gallery mein save ho gayi hai!")
                                    }.onFailure { err ->
                                        statusMessage = "Save error: ${err.message}"
                                    }
                                    isProcessing = false
                                }
                            },
                            modifier = Modifier.testTag("photo_save_button")
                        ) {
                            Icon(imageVector = Icons.Default.SaveAlt, contentDescription = "Save to Gallery", tint = MaterialTheme.colorScheme.primary)
                        }

                        IconButton(
                            onClick = {
                                val bmp = editedBitmap ?: return@IconButton
                                scope.launch {
                                    isProcessing = true
                                    val res = editorEngine.saveBitmapToGallery(bmp, "Imran_AI_Share")
                                    res.onSuccess { uri ->
                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "image/jpeg"
                                            putExtra(Intent.EXTRA_STREAM, uri)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(shareIntent, "Share Edited Photo"))
                                    }
                                    isProcessing = false
                                }
                            },
                            modifier = Modifier.testTag("photo_share_button")
                        ) {
                            Icon(imageVector = Icons.Default.Share, contentDescription = "Share", tint = AccentTeal)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Main Photo Display Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color(0xFF070B13)),
                contentAlignment = Alignment.Center
            ) {
                val displayBitmap = if (isHoldingOriginal) originalBitmap else editedBitmap

                if (displayBitmap != null) {
                    Image(
                        bitmap = displayBitmap.asImageBitmap(),
                        contentDescription = "Photo Preview",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onPress = {
                                        isHoldingOriginal = true
                                        tryAwaitRelease()
                                        isHoldingOriginal = false
                                    }
                                )
                            }
                    )

                    // Overlay hint: "Hold to see Original"
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.Black.copy(alpha = 0.55f),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = if (isHoldingOriginal) "Showing Original" else "Touch & Hold to compare",
                            color = Color.White,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    if (isProcessing) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.4f)),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = PrimaryNeon)
                        }
                    }
                } else {
                    // Empty state: Choose Photo Card
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(72.dp)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Aapki Photo, Aapki Marzi!",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Boss, gallery se koi bhi photo dein aur bol kar batayein kaisa look chahiye! Bilkul free aur instant editing.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.outline,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.testTag("choose_photo_studio_button")
                        ) {
                            Icon(imageVector = Icons.Default.AddPhotoAlternate, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Select Photo from Gallery")
                        }
                    }
                }
            }

            // Status message toast banner
            AnimatedVisibility(visible = statusMessage != null) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = statusMessage ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }

            // Natural Voice & Command Input Strip
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        IconButton(
                            onClick = onMicClick,
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(if (isListening) ElectricCyan else MaterialTheme.colorScheme.primaryContainer)
                                .testTag("studio_mic_button")
                        ) {
                            Icon(
                                imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                                contentDescription = "Voice Edit Command",
                                tint = if (isListening) Color.Black else MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        OutlinedTextField(
                            value = voiceInputText,
                            onValueChange = { voiceInputText = it },
                            placeholder = { Text("Bolain: 'Cinematic karo', 'Bright karo'...", fontSize = 13.sp) },
                            singleLine = true,
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("studio_voice_text_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                            ),
                            trailingIcon = {
                                if (voiceInputText.isNotBlank()) {
                                    IconButton(onClick = {
                                        applyVoiceInstruction(voiceInputText)
                                        voiceInputText = ""
                                    }) {
                                        Icon(imageVector = Icons.Default.Check, contentDescription = "Apply", tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier.size(44.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddPhotoAlternate,
                                contentDescription = "Change photo",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    // Quick Voice Command Suggestion Chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(top = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val quickIdeas = listOf(
                            "Bright karo",
                            "Cinematic filter",
                            "Golden Hour",
                            "Cyberpunk",
                            "Black and White",
                            "Vintage sepia",
                            "Boss badge",
                            "Vignette effect",
                            "Rotate karo",
                            "Flip mirror"
                        )
                        quickIdeas.forEach { idea ->
                            AssistChip(
                                onClick = { applyVoiceInstruction(idea) },
                                label = { Text(idea, fontSize = 11.sp) },
                                colors = AssistChipDefaults.assistChipColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                                )
                            )
                        }
                    }
                }
            }

            // Bottom Editing Tools & Tabs
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    TabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.primary
                    ) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            text = { Text("Filters / Rang", fontSize = 12.sp) },
                            icon = { Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        )
                        Tab(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            text = { Text("Adjust / Roshni", fontSize = 12.sp) },
                            icon = { Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        )
                        Tab(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            text = { Text("Transform", fontSize = 12.sp) },
                            icon = { Icon(Icons.AutoMirrored.Filled.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        )
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        when (selectedTab) {
                            0 -> {
                                // Filter Presets Carousel
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    FilterPreset.values().forEach { preset ->
                                        val isSelected = editState.preset == preset
                                        FilterChip(
                                            selected = isSelected,
                                            onClick = {
                                                triggerEditProcessing(
                                                    editState.copy(preset = preset),
                                                    "Jee Boss, ${preset.displayName} filter apply ho gaya!"
                                                )
                                            },
                                            label = { Text(preset.displayName, fontSize = 12.sp) },
                                            leadingIcon = if (isSelected) {
                                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                            } else null,
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                        )
                                    }
                                }
                            }
                            1 -> {
                                // Sliders: Brightness, Contrast, Saturation, Warmth
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .verticalScroll(rememberScrollState()),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    // Brightness
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Brightness6, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Brightness: ${editState.brightness.toInt()}", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                                    }
                                    Slider(
                                        value = editState.brightness,
                                        onValueChange = { b -> triggerEditProcessing(editState.copy(brightness = b)) },
                                        valueRange = -80f..80f,
                                        modifier = Modifier.height(28.dp)
                                    )

                                    // Contrast
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Contrast, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Contrast: ${String.format("%.1fx", editState.contrast)}", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                                    }
                                    Slider(
                                        value = editState.contrast,
                                        onValueChange = { c -> triggerEditProcessing(editState.copy(contrast = c)) },
                                        valueRange = 0.5f..1.8f,
                                        modifier = Modifier.height(28.dp)
                                    )

                                    // Saturation
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Saturation: ${String.format("%.1fx", editState.saturation)}", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                                    }
                                    Slider(
                                        value = editState.saturation,
                                        onValueChange = { s -> triggerEditProcessing(editState.copy(saturation = s)) },
                                        valueRange = 0f..2.2f,
                                        modifier = Modifier.height(28.dp)
                                    )
                                }
                            }
                            2 -> {
                                // Transform tools: Rotate, Flip, Vignette, Boss Badge
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = {
                                            triggerEditProcessing(
                                                editState.copy(rotation = (editState.rotation + 90f) % 360f),
                                                "Jee Boss, picture rotate kar di hai."
                                            )
                                        }
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Rotate 90°", fontSize = 12.sp)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            triggerEditProcessing(
                                                editState.copy(isFlipped = !editState.isFlipped),
                                                "Jee Boss, photo flip kar di hai."
                                            )
                                        }
                                    ) {
                                        Icon(Icons.Default.Flip, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Flip Mirror", fontSize = 12.sp)
                                    }

                                    FilterChip(
                                        selected = editState.hasVignette,
                                        onClick = {
                                            triggerEditProcessing(
                                                editState.copy(hasVignette = !editState.hasVignette),
                                                if (!editState.hasVignette) "Vignette on kar diya hai, Boss!" else "Vignette off kar diya."
                                            )
                                        },
                                        label = { Text("Vignette", fontSize = 12.sp) }
                                    )

                                    FilterChip(
                                        selected = editState.hasBossBadge,
                                        onClick = {
                                            triggerEditProcessing(
                                                editState.copy(hasBossBadge = !editState.hasBossBadge),
                                                if (!editState.hasBossBadge) "Boss Edition badge add ho gaya!" else "Badge remove kar diya."
                                            )
                                        },
                                        label = { Text("👑 Boss Badge", fontSize = 12.sp) },
                                        leadingIcon = {
                                            Icon(Icons.Default.WorkspacePremium, contentDescription = null, modifier = Modifier.size(14.dp))
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
