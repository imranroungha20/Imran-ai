package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonIndigo = Color(0xFF6366F1)
val DeepIndigo = Color(0xFF4338CA)
val ElectricCyan = Color(0xFF06B6D4)
val DarkNavyBg = Color(0xFF0B0F19)
val DarkNavySurface = Color(0xFF131B2E)
val DarkNavyCard = Color(0xFF1E293B)
val LightBg = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFF1F5F9)

val PrimaryNeon = Color(0xFF818CF8)
val AccentTeal = Color(0xFF2DD4BF)
val ErrorRed = Color(0xFFF87171)
val SuccessGreen = Color(0xFF34D399)
val TextMuted = Color(0xFF94A3B8)
