package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonIndigo
import com.example.ui.theme.PrimaryNeon

@Composable
fun VoiceVisualizerOrb(
    isListening: Boolean,
    isSpeaking: Boolean,
    rmsLevel: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isListening) 1.22f else 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(850, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val rmsScaled by animateFloatAsState(
        targetValue = if (isListening) 1f + (rmsLevel * 0.35f) else 1f,
        animationSpec = tween(140),
        label = "rmsScaled"
    )

    val baseSize = 180.dp

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(240.dp)
            .semantics { contentDescription = if (isListening) "Stop voice input" else "Start voice input" }
    ) {
        // Outer pulsing neon ring when listening or speaking
        if (isListening || isSpeaking) {
            Box(
                modifier = Modifier
                    .size(baseSize * 1.3f)
                    .scale(pulseScale * rmsScaled)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                (if (isListening) ElectricCyan else PrimaryNeon).copy(alpha = 0.45f),
                                Color.Transparent
                            )
                        )
                    )
            )
            Box(
                modifier = Modifier
                    .size(baseSize * 1.15f)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                (if (isListening) NeonIndigo else ElectricCyan).copy(alpha = 0.55f),
                                Color.Transparent
                            )
                        )
                    )
            )
        }

        // Active Neon Border ring
        val borderColor = when {
            isListening -> ElectricCyan
            isSpeaking -> PrimaryNeon
            else -> ElectricCyan.copy(alpha = 0.7f)
        }

        // Central Microphone Picture Badge Button
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(baseSize)
                .scale(if (isListening) rmsScaled else 1f)
                .shadow(16.dp, CircleShape, spotColor = borderColor)
                .clip(CircleShape)
                .border(3.dp, borderColor, CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(bounded = true, radius = baseSize / 2),
                    onClick = onClick
                )
                .testTag("microphone_main_button")
        ) {
            // User's custom Imran AI badge graphic
            Image(
                painter = painterResource(id = R.drawable.img_imran_mic_badge),
                contentDescription = "Imran AI Voice Microphone Button",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // When actively listening or speaking, overlay subtle glowing indicator badge
            if (isListening) {
                Surface(
                    shape = CircleShape,
                    color = Color.Black.copy(alpha = 0.55f),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 10.dp)
                ) {
                    Box(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Listening",
                            tint = ElectricCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            } else if (isSpeaking) {
                Surface(
                    shape = CircleShape,
                    color = Color.Black.copy(alpha = 0.55f),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 10.dp)
                ) {
                    Box(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "Speaking",
                            tint = PrimaryNeon,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}
