package com.example.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.ActionType
import com.example.data.model.CommandAction

@Composable
fun ActionConfirmationDialog(
    action: CommandAction,
    onConfirm: () -> Unit,
    onCancel: () -> Unit
) {
    val icon = when (action.type) {
        ActionType.PHONE_CALL -> Icons.Default.Call
        ActionType.SEND_SMS -> Icons.AutoMirrored.Filled.Message
        ActionType.WHATSAPP_MESSAGE, ActionType.WHATSAPP_CALL -> Icons.AutoMirrored.Filled.Message
        ActionType.ACCESSIBILITY_NAV -> Icons.Default.Lock
        else -> Icons.Default.Warning
    }

    val confirmButtonText = when (action.type) {
        ActionType.PHONE_CALL -> "Call Now"
        ActionType.SEND_SMS -> "Draft & Send"
        ActionType.WHATSAPP_MESSAGE -> "Open WhatsApp"
        ActionType.WHATSAPP_CALL -> "Open Chat"
        ActionType.ACCESSIBILITY_NAV -> "Lock Screen"
        else -> "Confirm"
    }

    AlertDialog(
        onDismissRequest = onCancel,
        icon = {
            Icon(
                imageVector = icon,
                contentDescription = "Confirmation Icon",
                tint = MaterialTheme.colorScheme.primary
            )
        },
        title = {
            Text(
                text = action.confirmationTitle ?: "Confirm Sensitive Action",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = action.confirmationMessage ?: "Do you want to proceed with this action?",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (!action.explanationNote.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = action.explanationNote,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                modifier = Modifier.testTag("action_confirm_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Text(confirmButtonText)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onCancel,
                modifier = Modifier.testTag("action_cancel_button")
            ) {
                Text("Cancel / Mansookh")
            }
        }
    )
}
