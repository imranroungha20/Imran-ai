package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.AssistantApplication
import com.example.data.model.ActionType
import com.example.data.model.ChatMessage
import com.example.data.model.CommandAction
import com.example.engine.ExecutionResult
import com.example.engine.VoiceSpeechManager
import com.example.service.AssistantAccessibilityService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

enum class AssistantTab {
    HOME,
    CHAT,
    PERMISSIONS,
    SETTINGS,
    PHOTO_STUDIO
}

data class AssistantUiState(
    val isListening: Boolean = false,
    val isSpeaking: Boolean = false,
    val rmsLevel: Float = 0f,
    val liveTranscript: String = "",
    val pendingConfirmation: CommandAction? = null,
    val userName: String = "Imran",
    val userTitle: String = "Boss",
    val userPhotoUri: String? = null,
    val currentLanguage: String = "auto",
    val isTtsEnabled: Boolean = true,
    val ttsRate: Float = 0.98f,
    val ttsPitch: Float = 1.05f,
    val geminiKeyConfigured: Boolean = false,
    val isAccessibilityActive: Boolean = false,
    val currentTab: AssistantTab = AssistantTab.HOME,
    val photoStudioPrompt: String? = null,
    val isContinuousMode: Boolean = true,
    val isProcessing: Boolean = false,
    val statusBanner: String? = null,
    val showFirstLaunchSetup: Boolean = false
)

class AssistantViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as AssistantApplication
    private val chatDao = app.database.chatDao()
    private val prefs = app.userPreferences
    private val parser = app.intentParser
    private val executor = app.deviceActionExecutor
    private val gemini = app.geminiClient

    val chatMessages: StateFlow<List<ChatMessage>> = chatDao.getAllMessages()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiState = MutableStateFlow(
        AssistantUiState(
            userName = prefs.userName,
            userTitle = prefs.userTitle,
            userPhotoUri = prefs.userPhotoUri,
            currentLanguage = prefs.speechLanguage,
            isTtsEnabled = prefs.isTtsEnabled,
            ttsRate = prefs.ttsRate,
            ttsPitch = prefs.ttsPitch,
            geminiKeyConfigured = prefs.customGeminiApiKey.isNotBlank() || com.example.BuildConfig.GEMINI_API_KEY.isNotBlank() && com.example.BuildConfig.GEMINI_API_KEY != "MY_GEMINI_API_KEY",
            isAccessibilityActive = AssistantAccessibilityService.isServiceEnabled,
            isContinuousMode = prefs.isContinuousMode,
            showFirstLaunchSetup = !prefs.isSetupCompleted
        )
    )
    val uiState: StateFlow<AssistantUiState> = _uiState.asStateFlow()

    private val speechManager: VoiceSpeechManager

    init {
        speechManager = VoiceSpeechManager(
            context = application,
            onResultReceived = { recognizedText ->
                processUserInput(recognizedText)
            },
            onErrorReceived = { errorMsg ->
                _uiState.value = _uiState.value.copy(
                    statusBanner = errorMsg,
                    isProcessing = false
                )
            },
            onSpeakingFinished = {
                if (_uiState.value.isContinuousMode && !_uiState.value.isListening) {
                    viewModelScope.launch {
                        kotlinx.coroutines.delay(450)
                        if (_uiState.value.isContinuousMode && !_uiState.value.isListening && !_uiState.value.isSpeaking) {
                            speechManager.startListening(_uiState.value.currentLanguage)
                        }
                    }
                }
            }
        )

        viewModelScope.launch {
            speechManager.isListening.collect { listening ->
                _uiState.value = _uiState.value.copy(isListening = listening)
            }
        }
        viewModelScope.launch {
            speechManager.isSpeaking.collect { speaking ->
                _uiState.value = _uiState.value.copy(isSpeaking = speaking)
            }
        }
        viewModelScope.launch {
            speechManager.rmsLevel.collect { rms ->
                _uiState.value = _uiState.value.copy(rmsLevel = rms)
            }
        }
        viewModelScope.launch {
            speechManager.liveSpokenText.collect { transcript ->
                _uiState.value = _uiState.value.copy(liveTranscript = transcript)
            }
        }
    }

    fun setTab(tab: AssistantTab) {
        _uiState.value = _uiState.value.copy(currentTab = tab)
    }

    fun dismissFirstLaunchSetup() {
        prefs.isSetupCompleted = true
        _uiState.value = _uiState.value.copy(showFirstLaunchSetup = false)
    }

    fun toggleListening() {
        if (_uiState.value.isListening) {
            speechManager.stopListening()
        } else {
            speechManager.startListening(_uiState.value.currentLanguage)
        }
    }

    fun stopListening() {
        speechManager.stopListening()
    }

    fun stopSpeaking() {
        speechManager.stopSpeaking()
    }

    fun clearStatusBanner() {
        _uiState.value = _uiState.value.copy(statusBanner = null)
    }

    fun refreshAccessibilityStatus() {
        _uiState.value = _uiState.value.copy(
            isAccessibilityActive = AssistantAccessibilityService.isServiceEnabled
        )
    }

    fun processUserInput(input: String) {
        val trimmed = input.trim()
        if (trimmed.isBlank()) return

        val lower = trimmed.lowercase(java.util.Locale.ROOT)

        // Hands-free stop speech command:
        if (lower == "bas" || lower == "stop" || lower == "chup" || lower == "khamosh" || lower == "ruk jao") {
            stopSpeaking()
            stopListening()
            return
        }

        // Hands-free voice confirmation or cancellation for sensitive commands:
        val pending = _uiState.value.pendingConfirmation
        if (pending != null) {
            if (lower.contains("haan") || lower.contains("yes") || lower.contains("kar do") || lower.contains("kardo") ||
                lower.contains("bhejo") || lower.contains("call lagao") || lower.contains("lagao") || lower.contains("theek hai") ||
                lower.contains("bilkul") || lower.contains("sure") || lower.contains("ok") || lower.contains("okay") || lower.contains("jee")) {
                confirmPendingAction()
                return
            } else if (lower.contains("nahi") || lower.contains("no") || lower.contains("cancel") || lower.contains("mat karo") ||
                lower.contains("rehne do") || lower.contains("chhoro") || lower.contains("rok do")) {
                cancelPendingAction()
                return
            }
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isProcessing = true, liveTranscript = "")

            // 1. Insert user message in Room
            chatDao.insertMessage(
                ChatMessage(
                    text = trimmed,
                    isFromUser = true,
                    actionType = "USER_INPUT"
                )
            )

            // 2. Parse command using dual Urdu & English NLU Intent Parser
            val action = parser.parse(trimmed)

            // 3. Handle Sensitive Confirmation Requirement
            if (action.isSensitive) {
                _uiState.value = _uiState.value.copy(
                    pendingConfirmation = action,
                    isProcessing = false
                )

                val promptText = action.confirmationMessage ?: "Aap yeh action perform karna chahte hain?"
                chatDao.insertMessage(
                    ChatMessage(
                        text = promptText,
                        isFromUser = false,
                        actionType = action.type.name,
                        actionDetails = action.summary,
                        status = "PENDING_CONFIRMATION"
                    )
                )

                if (_uiState.value.isTtsEnabled) {
                    val promptSpoken = action.confirmationTitle ?: promptText
                    speechManager.speak(promptSpoken, _uiState.value.ttsRate, _uiState.value.ttsPitch)
                }
                return@launch
            }

            // 4. Handle Free Photo Studio & Photo Editing Command
            if (action.type == ActionType.PHOTO_STUDIO) {
                _uiState.value = _uiState.value.copy(
                    currentTab = AssistantTab.PHOTO_STUDIO,
                    photoStudioPrompt = action.photoEditPrompt,
                    isProcessing = false
                )
                val response = action.spokenResponse ?: "Jee Boss! Photo Studio khol diya hai. Jo photo aap dein, jaisa bolenge waise hi bilkul free bana doonga!"
                chatDao.insertMessage(
                    ChatMessage(
                        text = response,
                        isFromUser = false,
                        actionType = action.type.name,
                        status = "SUCCESS"
                    )
                )
                if (_uiState.value.isTtsEnabled) {
                    speechManager.speak(response, _uiState.value.ttsRate, _uiState.value.ttsPitch)
                }
                return@launch
            }

            // 5. If Unknown action: Try Gemini if key configured, else provide smart offline answer
            if (action.type == ActionType.UNKNOWN) {
                handleUnknownOrConversationalQuery(trimmed)
                return@launch
            }

            // 6. Execute safe automatic action
            executeActionDirectly(action)
        }
    }

    private suspend fun handleUnknownOrConversationalQuery(query: String) {
        val hasGemini = _uiState.value.geminiKeyConfigured
        if (hasGemini) {
            val recentContext = chatMessages.value.takeLast(10)
                .joinToString("\n") { (if (it.isFromUser) "User: " else "Assistant: ") + it.text }

            val result = gemini.generateAnswer(query, recentContext)
            result.onSuccess { answer ->
                chatDao.insertMessage(
                    ChatMessage(
                        text = answer,
                        isFromUser = false,
                        actionType = "GEMINI_ANSWER",
                        status = "SUCCESS"
                    )
                )
                if (_uiState.value.isTtsEnabled) {
                    speechManager.speak(answer, _uiState.value.ttsRate, _uiState.value.ttsPitch)
                }
            }.onFailure { error ->
                val fallback = "Jee Boss, main sun raha hoon! Main aapke orders par WhatsApp, calls, SMS, alarms, YouTube, aur Photo Studio mein photos bilkul free edit kar sakta hoon. Hukum karein Boss!"
                chatDao.insertMessage(
                    ChatMessage(
                        text = fallback,
                        isFromUser = false,
                        actionType = "OFFLINE_GUIDE",
                        status = "INFO"
                    )
                )
                if (_uiState.value.isTtsEnabled) {
                    speechManager.speak(fallback, _uiState.value.ttsRate, _uiState.value.ttsPitch)
                }
            }
        } else {
            // Free offline friendly explanation
            val offlineResponse = "Jee Boss! Main aapka friendly personal voice assistant hoon. Aap mujhse WhatsApp, phone calls, alarms, YouTube, ya 'Photo edit krdo' keh sakte hain. Jo photo aap dein, jaisa bolenge waise hi bilkul free bana doonga!"
            chatDao.insertMessage(
                ChatMessage(
                    text = offlineResponse,
                    isFromUser = false,
                    actionType = "OFFLINE_GUIDE",
                    status = "INFO"
                )
            )
            if (_uiState.value.isTtsEnabled) {
                speechManager.speak(offlineResponse, _uiState.value.ttsRate, _uiState.value.ttsPitch)
            }
        }
        _uiState.value = _uiState.value.copy(isProcessing = false)
    }

    fun openPhotoStudio(prompt: String? = null) {
        _uiState.value = _uiState.value.copy(
            currentTab = AssistantTab.PHOTO_STUDIO,
            photoStudioPrompt = prompt
        )
        if (_uiState.value.isTtsEnabled) {
            speechManager.speak("Jee Boss, Photo Studio khol diya hai! Jo photo dein jaisa bolenge waise hi bana doonga.", _uiState.value.ttsRate, _uiState.value.ttsPitch)
        }
    }

    fun speakText(text: String) {
        if (_uiState.value.isTtsEnabled) {
            speechManager.speak(text, _uiState.value.ttsRate, _uiState.value.ttsPitch)
        }
    }

    fun toggleContinuousMode() {
        val next = !_uiState.value.isContinuousMode
        prefs.isContinuousMode = next
        _uiState.value = _uiState.value.copy(
            isContinuousMode = next,
            statusBanner = if (next) "🎙️ Hands-Free Friend Mode ON: Bas bolte rahein, type karne ki zaroorat nahi!" else "Manual Mic Mode ON"
        )
        if (next && !_uiState.value.isListening && !_uiState.value.isSpeaking) {
            speechManager.startListening(_uiState.value.currentLanguage)
        }
    }

    fun confirmPendingAction() {
        val action = _uiState.value.pendingConfirmation ?: return
        _uiState.value = _uiState.value.copy(pendingConfirmation = null, isProcessing = true)

        viewModelScope.launch {
            executeActionDirectly(action)
        }
    }

    fun cancelPendingAction() {
        val action = _uiState.value.pendingConfirmation ?: return
        _uiState.value = _uiState.value.copy(pendingConfirmation = null)

        viewModelScope.launch {
            val cancelText = "Action '${action.summary}' mansookh (cancel) kar diya gaya."
            chatDao.insertMessage(
                ChatMessage(
                    text = cancelText,
                    isFromUser = false,
                    actionType = action.type.name,
                    status = "CANCELLED"
                )
            )
            if (_uiState.value.isTtsEnabled) {
                speechManager.speak(cancelText, _uiState.value.ttsRate)
            }
        }
    }

    private suspend fun executeActionDirectly(action: CommandAction) {
        val execResult = executor.execute(action)
        val (resultMessage, status) = when (execResult) {
            is ExecutionResult.Success -> Pair(execResult.message, "SUCCESS")
            is ExecutionResult.Fallback -> Pair(execResult.message, "INFO")
            is ExecutionResult.PermissionNeeded -> Pair(execResult.message, "REQUIRES_PERMISSION")
            is ExecutionResult.Failure -> Pair(execResult.reason, "FAILED")
        }

        chatDao.insertMessage(
            ChatMessage(
                text = resultMessage,
                isFromUser = false,
                actionType = action.type.name,
                actionDetails = action.summary,
                status = status
            )
        )

        _uiState.value = _uiState.value.copy(isProcessing = false)

        if (_uiState.value.isTtsEnabled) {
            val spoken = action.spokenResponse ?: resultMessage
            speechManager.speak(spoken, _uiState.value.ttsRate)
        }
    }

    fun clearChatHistory() {
        viewModelScope.launch {
            chatDao.clearAllMessages()
            _uiState.value = _uiState.value.copy(statusBanner = "Chat history deleted.")
        }
    }

    fun saveUserProfile(name: String) {
        prefs.userName = name
        _uiState.value = _uiState.value.copy(userName = name)
    }

    fun saveUserPhoto(uri: Uri) {
        viewModelScope.launch {
            try {
                // Copy photo to app's private filesDir so it persists across reboots
                val inputStream = app.contentResolver.openInputStream(uri)
                val targetFile = File(app.filesDir, "user_profile_photo.jpg")
                val outputStream = FileOutputStream(targetFile)
                inputStream?.use { input ->
                    outputStream.use { output ->
                        input.copyTo(output)
                    }
                }
                val localPath = targetFile.absolutePath
                prefs.userPhotoUri = localPath
                _uiState.value = _uiState.value.copy(userPhotoUri = localPath)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun saveGeminiApiKey(key: String) {
        prefs.customGeminiApiKey = key.trim()
        val isConfigured = key.isNotBlank() || com.example.BuildConfig.GEMINI_API_KEY.isNotBlank() && com.example.BuildConfig.GEMINI_API_KEY != "MY_GEMINI_API_KEY"
        _uiState.value = _uiState.value.copy(
            geminiKeyConfigured = isConfigured,
            statusBanner = if (key.isNotBlank()) "Gemini API key saved." else "Using Free Offline Engine."
        )
    }

    fun updateSpeechLanguage(lang: String) {
        prefs.speechLanguage = lang
        _uiState.value = _uiState.value.copy(currentLanguage = lang)
    }

    fun updateTtsSettings(enabled: Boolean, rate: Float) {
        prefs.isTtsEnabled = enabled
        prefs.ttsRate = rate
        _uiState.value = _uiState.value.copy(isTtsEnabled = enabled, ttsRate = rate)
    }

    override fun onCleared() {
        super.onCleared()
        speechManager.destroy()
    }
}
