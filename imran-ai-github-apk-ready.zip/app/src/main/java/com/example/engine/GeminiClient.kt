package com.example.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiClient(
    private val apiKeyProvider: () -> String
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    suspend fun generateAnswer(userPrompt: String, conversationContext: String = ""): Result<String> {
        val apiKey = apiKeyProvider().trim()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return Result.failure(IllegalStateException("No Gemini API key provided. Free offline intent parsing was used."))
        }

        return withContext(Dispatchers.IO) {
            try {
                val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=$apiKey"

                val promptWithSystem = if (conversationContext.isNotBlank()) {
                    "System: You are 'Imran AI', a loyal, super friendly personal voice assistant on Android. You ALWAYS address the user as 'Boss' ('Jee Boss', 'Haan Boss'). Respond warmly, concisely and respectfully in Roman Urdu, Urdu, or English matching the user. Keep responses clear and pleasant for voice speech (under 3 sentences). Everything is 100% free.\nContext:\n$conversationContext\nUser: $userPrompt"
                } else {
                    "System: You are 'Imran AI', a loyal, super friendly personal voice assistant on Android. You ALWAYS address the user as 'Boss' ('Jee Boss', 'Haan Boss'). Respond warmly, concisely and respectfully in Roman Urdu, Urdu, or English matching the user. Keep responses clear and pleasant for voice speech (under 3 sentences). Everything is 100% free.\nUser: $userPrompt"
                }

                val jsonBody = JSONObject().apply {
                    val contentsArray = JSONArray().apply {
                        val contentObj = JSONObject().apply {
                            val partsArray = JSONArray().apply {
                                val textPart = JSONObject().apply {
                                    put("text", promptWithSystem)
                                }
                                put(textPart)
                            }
                            put("parts", partsArray)
                        }
                        put(contentObj)
                    }
                    put("contents", contentsArray)
                }

                val mediaType = "application/json; charset=utf-8".toMediaType()
                val requestBody = jsonBody.toString().toRequestBody(mediaType)
                val request = Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .build()

                client.newCall(request).execute().use { response ->
                    val respStr = response.body?.string() ?: ""
                    if (!response.isSuccessful) {
                        return@withContext Result.failure(
                            Exception("Gemini API error (HTTP ${response.code}): $respStr")
                        )
                    }

                    val jsonResp = JSONObject(respStr)
                    val candidates = jsonResp.optJSONArray("candidates")
                    if (candidates != null && candidates.length() > 0) {
                        val firstCandidate = candidates.getJSONObject(0)
                        val content = firstCandidate.optJSONObject("content")
                        val parts = content?.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            val text = parts.getJSONObject(0).optString("text")
                            return@withContext Result.success(text.trim())
                        }
                    }
                    Result.failure(Exception("Could not extract answer from Gemini response."))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }
}
