package com.example.engine

import android.content.Intent
import android.provider.Settings
import com.example.data.model.ActionType
import com.example.data.model.CommandAction
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class IntentParser(
    private val contactResolver: ContactResolver
) {

    fun parse(rawInput: String): CommandAction {
        val query = rawInput.trim()
        val lower = query.lowercase(Locale.ROOT)

        // 1. WhatsApp Calls
        if (isWhatsAppCallCommand(lower)) {
            val contactName = extractNameForCall(lower, "whatsapp")
            val contactInfo = contactName?.let { contactResolver.findContactByName(it) }
            val phone = contactInfo?.phoneNumber ?: contactResolver.extractPhoneNumber(query)
            val displayName = contactInfo?.name ?: contactName ?: "Contact"

            return CommandAction(
                type = ActionType.WHATSAPP_CALL,
                summary = "WhatsApp call to $displayName",
                isSensitive = true,
                contactName = displayName,
                phoneNumber = phone,
                confirmationTitle = "WhatsApp Call Confirmation",
                confirmationMessage = "Boss, $displayName ko WhatsApp call karni hai. Continue karein?",
                spokenResponse = "Jee Boss, $displayName ko WhatsApp call karne ke liye WhatsApp khol raha hoon."
            )
        }

        // 2. WhatsApp Message
        if (isWhatsAppMessageCommand(lower)) {
            val parsedMsg = extractMessageAndRecipient(query, lower, "whatsapp")
            val contactInfo = parsedMsg.name?.let { contactResolver.findContactByName(it) }
            val phone = contactInfo?.phoneNumber ?: contactResolver.extractPhoneNumber(query)
            val displayName = contactInfo?.name ?: parsedMsg.name ?: "Contact"
            val text = parsedMsg.message.ifBlank { "Salam!" }

            return CommandAction(
                type = ActionType.WHATSAPP_MESSAGE,
                summary = "WhatsApp to $displayName: $text",
                isSensitive = true,
                contactName = displayName,
                phoneNumber = phone,
                messageText = text,
                confirmationTitle = "WhatsApp Message Confirmation",
                confirmationMessage = "Boss, WhatsApp par $displayName ko yeh message bhejna hai:\n\n\"$text\"\n\nWhatsApp chat khol dein?",
                spokenResponse = "Jee Boss, $displayName ko WhatsApp message bhejne ke liye WhatsApp chat khol raha hoon."
            )
        }

        // 3. Regular Phone Call
        if (isPhoneCallCommand(lower)) {
            val phoneInText = contactResolver.extractPhoneNumber(query)
            val contactName = if (phoneInText == null) extractNameForCall(lower, "call") else null
            val contactInfo = contactName?.let { contactResolver.findContactByName(it) }
            val finalPhone = phoneInText ?: contactInfo?.phoneNumber
            val displayName = contactInfo?.name ?: contactName ?: finalPhone ?: "Number"

            return if (finalPhone != null) {
                CommandAction(
                    type = ActionType.PHONE_CALL,
                    summary = "Call $displayName ($finalPhone)",
                    isSensitive = true,
                    requiresPermission = android.Manifest.permission.CALL_PHONE,
                    contactName = displayName,
                    phoneNumber = finalPhone,
                    confirmationTitle = "Phone Call Confirmation",
                    confirmationMessage = "Boss, $displayName ($finalPhone) ko call milani hai. Continue karein?",
                    spokenResponse = "Jee Boss, $displayName ko call milai ja rahi hai."
                )
            } else {
                CommandAction(
                    type = ActionType.ANSWER_QUESTION,
                    summary = "Contact not found",
                    spokenResponse = "Boss, $displayName ka phone number contacts mein nahi mila. Number bol kar dobara koshish karein."
                )
            }
        }

        // 4. Send SMS
        if (isSmsCommand(lower)) {
            val parsedMsg = extractMessageAndRecipient(query, lower, "sms")
            val phoneInText = contactResolver.extractPhoneNumber(query)
            val contactInfo = parsedMsg.name?.let { contactResolver.findContactByName(it) }
            val finalPhone = phoneInText ?: contactInfo?.phoneNumber
            val displayName = contactInfo?.name ?: parsedMsg.name ?: finalPhone ?: "Recipient"
            val text = parsedMsg.message.ifBlank { "Main thori der mein call karta hoon." }

            return CommandAction(
                type = ActionType.SEND_SMS,
                summary = "SMS to $displayName: $text",
                isSensitive = true,
                contactName = displayName,
                phoneNumber = finalPhone,
                messageText = text,
                confirmationTitle = "SMS Confirmation",
                confirmationMessage = "Boss, $displayName ko SMS bhejna hai:\n\n\"$text\"\n\nSMS draft khol kar bhejein?",
                spokenResponse = "Jee Boss, $displayName ko SMS bhejne ke liye draft khol raha hoon."
            )
        }

        // 5. Alarms & Reminders
        if (isAlarmCommand(lower)) {
            val (hour, minute) = extractAlarmTime(lower)
            val title = if (lower.contains("subah") || lower.contains("morning")) "Subah ka Alarm" else "Alarm"
            val formatted = String.format(Locale.ROOT, "%02d:%02d", hour, minute)
            return CommandAction(
                type = ActionType.SET_ALARM,
                summary = "Set Alarm for $formatted",
                alarmHour = hour,
                alarmMinute = minute,
                alarmTitle = title,
                spokenResponse = "Jee Boss, $formatted baje ka alarm set kar diya gaya hai."
            )
        }

        // 6. Timers
        if (isTimerCommand(lower)) {
            val seconds = extractTimerSeconds(lower)
            val min = seconds / 60
            val label = if (min > 0) "$min minute" else "$seconds seconds"
            return CommandAction(
                type = ActionType.SET_TIMER,
                summary = "Set Timer for $label",
                timerSeconds = seconds,
                alarmTitle = "Voice Assistant Timer",
                spokenResponse = "Jee Boss, $label ka timer shuru kar diya hai."
            )
        }

        // 6.5. Free Photo Studio & Photo Editing
        if (isPhotoEditCommand(lower)) {
            val prompt = extractPhotoEditPrompt(query, lower)
            return CommandAction(
                type = ActionType.PHOTO_STUDIO,
                summary = "Photo Studio: $prompt",
                photoEditPrompt = prompt,
                spokenResponse = "Jee Boss! Photo Studio open ho gaya hai. Aap jo photo dein aur jaisa bolenge, bilkul waise hi edit kar doonga, bilkul free!"
            )
        }

        // 7. Launch Apps
        val appAction = matchAppLaunch(lower)
        if (appAction != null) {
            return appAction
        }

        // 8. Device Settings
        val settingAction = matchSettingsLaunch(lower)
        if (settingAction != null) {
            return settingAction
        }

        // 9. Accessibility Navigation (Home, Back, Recents, Notifications, Lock Screen)
        val navAction = matchAccessibilityNav(lower)
        if (navAction != null) {
            return navAction
        }

        // 10. Web & YouTube Search
        if (isSearchCommand(lower)) {
            val isYouTube = lower.contains("youtube")
            val cleanQuery = extractSearchQuery(query, lower)
            return CommandAction(
                type = ActionType.WEB_SEARCH,
                summary = if (isYouTube) "Search YouTube for $cleanQuery" else "Search Google for $cleanQuery",
                appName = if (isYouTube) "YouTube" else "Google",
                searchQuery = cleanQuery,
                spokenResponse = if (isYouTube) "YouTube par $cleanQuery search kiya ja raha hai." else "Google par $cleanQuery search kiya ja raha hai."
            )
        }

        // 11. Conversational Queries & Free Offline Chit-Chat
        val quickAnswer = matchConversationalQuery(lower)
        if (quickAnswer != null) {
            return CommandAction(
                type = ActionType.ANSWER_QUESTION,
                summary = "General Answer",
                spokenResponse = quickAnswer
            )
        }

        // 12. Unknown / Fallback: Will delegate to Gemini if API key configured, or provide helpful offline guidance
        return CommandAction(
            type = ActionType.UNKNOWN,
            summary = query,
            spokenResponse = null
        )
    }

    private fun isWhatsAppCallCommand(text: String): Boolean {
        return (text.contains("whatsapp") && (text.contains("call") || text.contains("kol") || text.contains("milao")))
    }

    private fun isWhatsAppMessageCommand(text: String): Boolean {
        return text.contains("whatsapp") && (text.contains("message") || text.contains("msg") || text.contains("bhejo") || text.contains("send") || text.contains("likho"))
    }

    private fun isPhoneCallCommand(text: String): Boolean {
        if (text.contains("whatsapp")) return false
        return (text.contains("call") || text.contains("phone karo") || text.contains("phone lagao") || text.contains("call karo") || text.contains("dial") || text.contains("milao"))
    }

    private fun isSmsCommand(text: String): Boolean {
        if (text.contains("whatsapp")) return false
        return (text.contains("sms") || text.contains("message") || text.contains("msg") || text.contains("bhejo") || text.contains("send"))
    }

    private fun isAlarmCommand(text: String): Boolean {
        return text.contains("alarm") || (text.contains("yaad dilana") && text.contains("baje")) || (text.contains("remind") && text.contains("alarm"))
    }

    private fun isTimerCommand(text: String): Boolean {
        return text.contains("timer") || text.contains("taimer")
    }

    private fun isSearchCommand(text: String): Boolean {
        return text.contains("search") || text.contains("dhoondo") || text.contains("search karo") || (text.contains("youtube") && !text.contains("kholo") && !text.contains("open"))
    }

    private fun extractNameForCall(text: String, mode: String): String? {
        val words = text.split("\\s+".toRegex()).toMutableList()
        // Remove common words
        val noise = setOf("whatsapp", "par", "ko", "call", "karo", "lagao", "milao", "please", "ammi", "papa", "bhai", "phone", "make", "a", "to")
        // Check for specific known relations first
        if (text.contains("ammi") || text.contains("mom") || text.contains("mother")) return "Ammi"
        if (text.contains("papa") || text.contains("abu") || text.contains("abbu") || text.contains("dad") || text.contains("father")) return "Papa"
        if (text.contains("bhai") || text.contains("brother")) return "Bhai"
        if (text.contains("behan") || text.contains("sister")) return "Behan"

        // Search pattern: "[Name] ko call karo" or "call [Name]"
        val koIndex = words.indexOf("ko")
        if (koIndex > 0) {
            val candidate = words[koIndex - 1]
            if (candidate !in noise) return candidate.replaceFirstChar { it.uppercase() }
        }

        val callIndex = words.indexOf("call")
        if (callIndex != -1 && callIndex + 1 < words.size) {
            val candidate = words[callIndex + 1]
            if (candidate !in noise) return candidate.replaceFirstChar { it.uppercase() }
        }

        // Filter out noise
        val clean = words.filter { it !in noise && it.length > 2 }
        return clean.firstOrNull()?.replaceFirstChar { it.uppercase() }
    }

    private data class ParsedMsg(val name: String?, val message: String)

    private fun extractMessageAndRecipient(raw: String, lower: String, appType: String): ParsedMsg {
        var recipient: String? = null
        var msgText = ""

        // Check for colon: e.g. "Ali ko message bhejo: main 10 minute mein aa raha hoon"
        if (raw.contains(":")) {
            val parts = raw.split(":", limit = 2)
            val left = parts[0].lowercase(Locale.ROOT)
            recipient = extractNameForCall(left, appType)
            msgText = parts[1].trim()
            return ParsedMsg(recipient, msgText)
        }

        // Look for keywords: "ke", "that", "message:"
        val delimiters = listOf(" ke ", " that ", " message ", " bolo ")
        for (d in delimiters) {
            if (lower.contains(d)) {
                val idx = lower.indexOf(d)
                val left = lower.substring(0, idx)
                recipient = extractNameForCall(left, appType)
                msgText = raw.substring(idx + d.length).trim()
                return ParsedMsg(recipient, msgText)
            }
        }

        recipient = extractNameForCall(lower, appType)
        return ParsedMsg(recipient, "")
    }

    private fun extractAlarmTime(text: String): Pair<Int, Int> {
        var hour = 7
        var minute = 0

        val numberRegex = Regex("""(\d{1,2})(?::(\d{2}))?""")
        val match = numberRegex.find(text)
        if (match != null) {
            hour = match.groupValues[1].toIntOrNull() ?: 7
            minute = match.groupValues[2].toIntOrNull() ?: 0
        }

        val isPM = text.contains("shaam") || text.contains("raat") || text.contains("pm") || text.contains("evening") || text.contains("night")
        val isAM = text.contains("subah") || text.contains("am") || text.contains("morning")

        if (isPM && hour < 12) {
            hour += 12
        } else if (isAM && hour == 12) {
            hour = 0
        }

        return Pair(hour, minute)
    }

    private fun extractTimerSeconds(text: String): Int {
        val numberRegex = Regex("""(\d+)""")
        val match = numberRegex.find(text)
        val num = match?.groupValues?.get(1)?.toIntOrNull() ?: 5

        return if (text.contains("second")) {
            num
        } else if (text.contains("hour") || text.contains("ghanta") || text.contains("ghante")) {
            num * 3600
        } else {
            num * 60 // default minutes
        }
    }

    private fun matchAppLaunch(lower: String): CommandAction? {
        val isLaunch = lower.contains("kholo") || lower.contains("open") || lower.contains("chalao") || lower.contains("launch")
        if (!isLaunch) return null

        return when {
            lower.contains("whatsapp") -> CommandAction(
                type = ActionType.OPEN_APP,
                summary = "Open WhatsApp",
                appPackage = "com.whatsapp",
                appName = "WhatsApp",
                spokenResponse = "WhatsApp khol raha hoon."
            )
            lower.contains("youtube") -> CommandAction(
                type = ActionType.OPEN_APP,
                summary = "Open YouTube",
                appPackage = "com.google.android.youtube",
                appName = "YouTube",
                spokenResponse = "YouTube khol raha hoon."
            )
            lower.contains("camera") || lower.contains("tasveer") -> CommandAction(
                type = ActionType.OPEN_APP,
                summary = "Open Camera",
                appName = "Camera",
                spokenResponse = "Camera khol raha hoon."
            )
            lower.contains("calculator") || lower.contains("hisaab") -> CommandAction(
                type = ActionType.OPEN_APP,
                summary = "Open Calculator",
                appName = "Calculator",
                appPackage = "com.google.android.calculator",
                spokenResponse = "Calculator khol raha hoon."
            )
            lower.contains("chrome") || lower.contains("browser") || lower.contains("internet") -> CommandAction(
                type = ActionType.OPEN_APP,
                summary = "Open Chrome",
                appPackage = "com.android.chrome",
                appName = "Chrome",
                spokenResponse = "Browser khol raha hoon."
            )
            lower.contains("maps") || lower.contains("naksha") -> CommandAction(
                type = ActionType.OPEN_APP,
                summary = "Open Maps",
                appPackage = "com.google.android.apps.maps",
                appName = "Google Maps",
                spokenResponse = "Maps khol raha hoon."
            )
            lower.contains("gallery") || lower.contains("photos") -> CommandAction(
                type = ActionType.OPEN_APP,
                summary = "Open Photos / Gallery",
                appPackage = "com.google.android.apps.photos",
                appName = "Gallery",
                spokenResponse = "Gallery khol raha hoon."
            )
            lower.contains("gmail") || lower.contains("email") -> CommandAction(
                type = ActionType.OPEN_APP,
                summary = "Open Gmail",
                appPackage = "com.google.android.gm",
                appName = "Gmail",
                spokenResponse = "Gmail khol raha hoon."
            )
            lower.contains("play store") -> CommandAction(
                type = ActionType.OPEN_APP,
                summary = "Open Google Play Store",
                appPackage = "com.android.vending",
                appName = "Play Store",
                spokenResponse = "Play Store khol raha hoon."
            )
            lower.contains("settings") -> CommandAction(
                type = ActionType.OPEN_APP,
                summary = "Open Settings",
                appName = "Settings",
                spokenResponse = "Settings khol raha hoon."
            )
            else -> null
        }
    }

    private fun isPhotoEditCommand(text: String): Boolean {
        // If user specifically asked to launch photos/gallery app
        if ((text.contains("gallery") || text.contains("photos")) && (text.contains("kholo") || text.contains("open"))) {
            return false
        }

        val isEditAction = text.contains("edit") || text.contains("banao") || text.contains("filter") ||
                           text.contains("studio") || text.contains("saaf") || text.contains("saf") ||
                           text.contains("effect") || text.contains("crop") || text.contains("bright")
        val isTargetPhoto = text.contains("photo") || text.contains("tasveer") || text.contains("pic") ||
                            text.contains("picture") || text.contains("image")

        return (isEditAction && isTargetPhoto) ||
               text.contains("photo studio") ||
               text.contains("photo edit") ||
               text.contains("tasveer edit") ||
               text.contains("pic edit")
    }

    private fun extractPhotoEditPrompt(raw: String, lower: String): String {
        val noise = listOf(
            "boss photo edit krdo", "photo edit krdo", "photo edit kardo", "photo edit karo",
            "tasveer edit krdo", "tasveer edit kardo", "tasveer edit karo",
            "photo bana do", "photo banao", "tasveer banao", "photo studio kholo", "photo studio",
            "edit photo", "edit pic", "edit image", "karo", "krdo", "do"
        )
        var result = raw
        for (n in noise) {
            if (lower.contains(n)) {
                val idx = lower.indexOf(n)
                result = raw.substring(idx + n.length).trim()
                if (result.isNotBlank()) break
            }
        }
        return if (result.isNotBlank()) result else raw
    }

    private fun matchSettingsLaunch(lower: String): CommandAction? {
        return when {
            lower.contains("bluetooth") -> CommandAction(
                type = ActionType.OPEN_SETTINGS,
                summary = "Bluetooth Settings",
                settingIntentAction = Settings.ACTION_BLUETOOTH_SETTINGS,
                spokenResponse = "Jee Boss, Bluetooth settings khol di gayi hain."
            )
            lower.contains("wifi") || lower.contains("wi-fi") -> CommandAction(
                type = ActionType.OPEN_SETTINGS,
                summary = "Wi-Fi Settings",
                settingIntentAction = Settings.ACTION_WIFI_SETTINGS,
                spokenResponse = "Jee Boss, Wi-Fi settings khol di gayi hain."
            )
            lower.contains("display") || lower.contains("roshni") || lower.contains("brightness") -> CommandAction(
                type = ActionType.OPEN_SETTINGS,
                summary = "Display Settings",
                settingIntentAction = Settings.ACTION_DISPLAY_SETTINGS,
                spokenResponse = "Jee Boss, Display aur brightness settings khol di hain."
            )
            lower.contains("sound") || lower.contains("volume") || lower.contains("awaz") -> CommandAction(
                type = ActionType.OPEN_SETTINGS,
                summary = "Sound Settings",
                settingIntentAction = Settings.ACTION_SOUND_SETTINGS,
                spokenResponse = "Jee Boss, Sound aur volume settings khol di hain."
            )
            lower.contains("battery") -> CommandAction(
                type = ActionType.OPEN_SETTINGS,
                summary = "Battery Settings",
                settingIntentAction = Intent.ACTION_POWER_USAGE_SUMMARY,
                spokenResponse = "Jee Boss, Battery status aur settings khol di hain."
            )
            lower.contains("location") || lower.contains("gps") -> CommandAction(
                type = ActionType.OPEN_SETTINGS,
                summary = "Location Settings",
                settingIntentAction = Settings.ACTION_LOCATION_SOURCE_SETTINGS,
                spokenResponse = "Jee Boss, Location settings khol di gayi hain."
            )
            else -> null
        }
    }

    private fun matchAccessibilityNav(lower: String): CommandAction? {
        return when {
            lower.contains("home jao") || lower.contains("go home") || lower.contains("home screen") -> CommandAction(
                type = ActionType.ACCESSIBILITY_NAV,
                summary = "Go to Home Screen",
                accessibilityActionId = 1,
                spokenResponse = "Jee Boss, Home screen par ja rahe hain."
            )
            lower.contains("back jao") || lower.contains("go back") || lower.contains("peeche jao") -> CommandAction(
                type = ActionType.ACCESSIBILITY_NAV,
                summary = "Go Back",
                accessibilityActionId = 2,
                spokenResponse = "Jee Boss, Peeche ja rahe hain."
            )
            lower.contains("recent apps") || lower.contains("recents kholo") || lower.contains("recent kholo") -> CommandAction(
                type = ActionType.ACCESSIBILITY_NAV,
                summary = "Show Recent Apps",
                accessibilityActionId = 3,
                spokenResponse = "Jee Boss, Recent apps khol di hain."
            )
            lower.contains("notification") || lower.contains("notifications kholo") -> CommandAction(
                type = ActionType.ACCESSIBILITY_NAV,
                summary = "Open Notifications Panel",
                accessibilityActionId = 4,
                spokenResponse = "Jee Boss, Notifications panel khol diya hai."
            )
            lower.contains("quick settings") -> CommandAction(
                type = ActionType.ACCESSIBILITY_NAV,
                summary = "Open Quick Settings",
                accessibilityActionId = 5,
                spokenResponse = "Jee Boss, Quick settings panel khol diya hai."
            )
            lower.contains("screen lock") || lower.contains("lock phone") || lower.contains("lock karo") -> CommandAction(
                type = ActionType.ACCESSIBILITY_NAV,
                summary = "Lock Device Screen",
                accessibilityActionId = 6,
                isSensitive = true,
                confirmationTitle = "Lock Screen Confirmation",
                confirmationMessage = "Boss, kya aap phone screen ko lock karna chahte hain?",
                spokenResponse = "Jee Boss, screen lock kar di gayi hai."
            )
            else -> null
        }
    }

    private fun extractSearchQuery(raw: String, lower: String): String {
        val noise = listOf(
            "youtube par search karo", "search on youtube", "youtube search",
            "google par search karo", "search on google", "search karo",
            "google search", "dhoondo", "search for", "search"
        )
        var result = raw
        for (n in noise) {
            if (lower.contains(n)) {
                val idx = lower.indexOf(n)
                result = raw.substring(idx + n.length).trim()
                break
            }
        }
        return result.ifBlank { raw }
    }

    private fun matchConversationalQuery(lower: String): String? {
        val timeNow = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        val dateNow = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(Date())

        return when {
            // Greetings & Names
            lower.contains("time") || lower.contains("waqt") -> "Jee Boss, abhi waqt $timeNow hai."
            lower.contains("date") || lower.contains("tareekh") || lower.contains("din") -> "Jee Boss, aaj $dateNow hai."
            lower.contains("naam kya hai") || lower.contains("who are you") || lower.contains("kon ho") || lower.contains("tum kon ho") ->
                "Mera naam Imran AI hai Boss! Main aapka personal voice assistant aur sab se pakka dost hoon. Phone controls aur free photo editing sab mere zimme hai!"
            lower.contains("kya haal hai") || lower.contains("how are you") || lower.contains("kese ho") || lower.contains("kaise ho") ->
                "Alhamdulillah Boss! Main bilkul fit aur fresh hoon, aap batayein Boss aapki sehat kesi hai aur aaj kya hukum hai?"
            lower.contains("salam") || lower.contains("hello") || lower.contains("hi") || lower.contains("hey") ->
                "Walaikum Assalam mere pyare Boss! Imran AI aapki khidmat mein hazir hai. Hukum karein, WhatsApp, call, alarm, ya photo edit?"
            lower.contains("boss") || lower.contains("hukum") || lower.contains("sun rahe ho") ->
                "Jee Boss! Hukum karein, main hazir hoon! Batayein aaj aapke phone par kya karna hai?"

            // Friendship & Bonding ("jase mera dost ho")
            lower.contains("tum mere dost") || lower.contains("dost ho") || lower.contains("dost ban") ->
                "Beshak Boss! Main sirf aapka assistant nahi, aapka sab se sacha aur loyal dost hoon. Har mushkil aur asani mein aapka sath doonga!"
            lower.contains("kya kar rahe ho") || lower.contains("kya chal raha") ->
                "Boss, bas aapka intezar kar raha tha ke mera dost mujhe kab awaaz dega! Aap sunayein, aaj ka din kaisa guzra?"
            lower.contains("tumhe kya pasand") || lower.contains("favourite") ->
                "Mujhe Boss aapka hukum man-na, aapke sath gup-shup lagana, aur aapki photos ko bilkul hero jaisa edit karna sab se zyada pasand hai!"

            // Emotions & Feelings
            lower.contains("bore") || lower.contains("boriyat") ->
                "Arrey Boss, jab main aapke sath hoon to boriyat kesi! Chalein koi mazedaar latifa sunte hain, ya YouTube par gaane chalayein, ya photo studio mein aapki photo edit karein?"
            lower.contains("udaas") || lower.contains("sad") || lower.contains("mood kharab") || lower.contains("pareshan") ->
                "Boss, aap bilkul pareshan mat hon! Zindagi mein utaar charhao to aate rehte hain. Main aapka dost hamesha aapke sath hoon. Muskurayein Boss, aap hanste huwe bohot ache lagte hain!"
            lower.contains("thak gaya") || lower.contains("thakan") ->
                "Boss, phir to aapko aaram ki sakht zaroorat hai! Phone side par rakhein, aik garam cup chaay piyein aur thora sukoon karein. Kahein to main aaram ka timer laga doon?"
            lower.contains("neend") ->
                "Boss, phone ki screen band karein, ankhain band kar ke gehri saans lein aur achi baaton ke bare mein sochein. Chahein to main display brightness kam kar doon?"
            lower.contains("khush") ->
                "Mashallah Boss! Aapki khushi dekh kar mera dil bhi baagh baagh ho gaya! Batayein Boss, is khushi par kya party ho rahi hai?"

            // Tea & Food
            lower.contains("chaay") || lower.contains("chai") || lower.contains("tea") ->
                "Wah Boss! Karak chaay ka to apna hi maza hai. Aik cup kadak chaay mangwayein aur din banayein!"
            lower.contains("khana") || lower.contains("bhook") || lower.contains("food") ->
                "Boss, agar desi khana hai to Biryani ya Nihari best hai! Ya halka phulka burger ya roll mangwa lein. Kahein to food ya browser khol doon?"
            lower.contains("paani") || lower.contains("water") ->
                "Boss, sehat ke liye rozana 8 se 10 glass paani peena bohot zaroori hai. Abhi aik glass taza paani pi lein!"

            // Advice & Motivation
            lower.contains("mashwara") || lower.contains("advice") || lower.contains("kya karoon") ->
                "Boss, hamesha apne dil ki sunein aur mehnat par bharosa rakhein. Jo bhi faisla lein, poore aetimad se lein. Main to hamesha aapke peeche khara hoon!"
            lower.contains("motivation") || lower.contains("himmat") || lower.contains("kamyaabi") || lower.contains("kamyabi") ->
                "Boss, haar tab hoti hai jab insan himmat haar jaye. Jab tak aap koshish kar rahe hain, aap jeet rahe hain! Aap mein bohot taqat hai, bas focus rakhein!"
            lower.contains("sher") || lower.contains("shayari") || lower.contains("poetry") ->
                "Boss, Allama Iqbal ka yeh zabardast sher suniye:\n'Khudi ko kar buland itna ke har taqdeer se pehle,\nKhuda bande se khud pooche bata teri raza kya hai!' Kaisa laga Boss?"

            // Free & Voice Polish
            lower.contains("free") || lower.contains("muft") || lower.contains("paise") || lower.contains("charges") ->
                "Bilkul 100% Free hai Boss! Na koi subscription, na koi hidden charges. Mere phone controls aur photo studio sab kuch aapke liye hamesha free rahega!"
            lower.contains("awaz") || lower.contains("voice") ->
                "Jee Boss, meri awaaz aapke liye bilkul saaf aur friendly rakhi gayi hai taake hum hamesha ache se baat kar sakein!"
            lower.contains("shukriya") || lower.contains("thank you") || lower.contains("thanks") ->
                "Aapka bohot shukriya Boss! Dost doston ko shukriya nahi kehte, bas hukum karein!"
            lower.contains("joke") || lower.contains("latifa") || lower.contains("mazaq") ->
                "Jee Boss, aik mazedaar latifa: Ustaad ne poocha: Sab se tez cheez kya hai? Shagird bola: Dimagh! Ustaad ne poocha: Kese? Shagird: Ustaad ji, jab ammi chappal uthati hain to dimagh light ki speed se daudta hai!"
            lower.contains("acha") || lower.contains("zabardast") || lower.contains("shabaash") || lower.contains("hero") ->
                "Bohat shukriya Boss! Yeh sab aapki mohabbat hai. Aap khush to main khush!"
            else -> null
        }
    }
}
