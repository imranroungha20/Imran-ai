package com.example.engine

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.example.data.model.ActionType
import com.example.data.model.CommandAction
import com.example.service.AssistantAccessibilityService

sealed class ExecutionResult {
    data class Success(val message: String) : ExecutionResult()
    data class Fallback(val message: String) : ExecutionResult()
    data class PermissionNeeded(val permission: String, val message: String) : ExecutionResult()
    data class Failure(val reason: String) : ExecutionResult()
}

class DeviceActionExecutor(private val context: Context) {

    fun execute(action: CommandAction): ExecutionResult {
        return try {
            when (action.type) {
                ActionType.PHONE_CALL -> executePhoneCall(action)
                ActionType.SEND_SMS -> executeSendSms(action)
                ActionType.WHATSAPP_MESSAGE -> executeWhatsAppMessage(action)
                ActionType.WHATSAPP_CALL -> executeWhatsAppCall(action)
                ActionType.SET_ALARM -> executeSetAlarm(action)
                ActionType.SET_TIMER -> executeSetTimer(action)
                ActionType.OPEN_APP -> executeOpenApp(action)
                ActionType.OPEN_SETTINGS -> executeOpenSettings(action)
                ActionType.ACCESSIBILITY_NAV -> executeAccessibilityNav(action)
                ActionType.WEB_SEARCH -> executeWebSearch(action)
                else -> ExecutionResult.Success(action.spokenResponse ?: "Action executed.")
            }
        } catch (e: Exception) {
            ExecutionResult.Failure("Error performing action: ${e.localizedMessage ?: "Unknown error"}")
        }
    }

    private fun executePhoneCall(action: CommandAction): ExecutionResult {
        val number = action.phoneNumber ?: return ExecutionResult.Failure("Phone number not found.")
        val cleanNumber = number.replace("[^0-9+]".toRegex(), "")

        val hasCallPermission = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        val intent = if (hasCallPermission) {
            Intent(Intent.ACTION_CALL, Uri.parse("tel:$cleanNumber")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        } else {
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleanNumber")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        }

        context.startActivity(intent)
        val nameLabel = action.contactName ?: cleanNumber
        return if (hasCallPermission) {
            ExecutionResult.Success("$nameLabel ko call milayi ja rahi hai...")
        } else {
            ExecutionResult.Fallback("Dialer khol diya hai. Call lagane ke liye dial button press karein.")
        }
    }

    private fun executeSendSms(action: CommandAction): ExecutionResult {
        val number = action.phoneNumber ?: ""
        val text = action.messageText ?: ""

        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:${Uri.encode(number)}")
            putExtra("sms_body", text)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        return try {
            context.startActivity(intent)
            ExecutionResult.Success("SMS draft tayyar hai. Review karke send karein.")
        } catch (e: Exception) {
            ExecutionResult.Failure("SMS app nahi khul saki: ${e.message}")
        }
    }

    private fun executeWhatsAppMessage(action: CommandAction): ExecutionResult {
        val number = action.phoneNumber
        val text = action.messageText ?: ""

        val isInstalled = isPackageInstalled("com.whatsapp")
        if (!isInstalled) {
            return ExecutionResult.Failure("WhatsApp aapke phone par installed nahi hai.")
        }

        return try {
            if (!number.isNullOrBlank()) {
                // If country code is missing in Pakistan (+92), normalize:
                var formatted = number.replace("[^0-9+]".toRegex(), "")
                if (formatted.startsWith("03")) {
                    formatted = "92" + formatted.substring(1)
                } else if (formatted.startsWith("+")) {
                    formatted = formatted.substring(1)
                }

                val uri = Uri.parse("https://api.whatsapp.com/send?phone=$formatted&text=${Uri.encode(text)}")
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage("com.whatsapp")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                ExecutionResult.Success("WhatsApp chat khol di gayi hai. Bhejne ke liye Send par tap karein.")
            } else {
                // No number, share text to WhatsApp
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                    setPackage("com.whatsapp")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                ExecutionResult.Success("WhatsApp khol diya gaya hai. Contact select karein.")
            }
        } catch (e: Exception) {
            ExecutionResult.Failure("WhatsApp kholne mein masla aya: ${e.message}")
        }
    }

    private fun executeWhatsAppCall(action: CommandAction): ExecutionResult {
        val isInstalled = isPackageInstalled("com.whatsapp")
        if (!isInstalled) {
            return ExecutionResult.Failure("WhatsApp installed nahi hai.")
        }

        val number = action.phoneNumber
        return try {
            if (!number.isNullOrBlank()) {
                var formatted = number.replace("[^0-9+]".toRegex(), "")
                if (formatted.startsWith("03")) {
                    formatted = "92" + formatted.substring(1)
                } else if (formatted.startsWith("+")) {
                    formatted = formatted.substring(1)
                }
                val uri = Uri.parse("https://api.whatsapp.com/send?phone=$formatted")
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage("com.whatsapp")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                ExecutionResult.Success("${action.contactName ?: "Contact"} ki WhatsApp chat khol di hai. Call icon par tap kar ke call karein.")
            } else {
                val launchIntent = context.packageManager.getLaunchIntentForPackage("com.whatsapp")
                if (launchIntent != null) {
                    launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    context.startActivity(launchIntent)
                    ExecutionResult.Success("WhatsApp khol diya gaya hai. Call icon par tap karein.")
                } else {
                    ExecutionResult.Failure("WhatsApp launch nahi ho saka.")
                }
            }
        } catch (e: Exception) {
            ExecutionResult.Failure("WhatsApp open karte waqt masla aya: ${e.message}")
        }
    }

    private fun executeSetAlarm(action: CommandAction): ExecutionResult {
        val hour = action.alarmHour ?: return ExecutionResult.Failure("Alarm ka waqt samajh nahi aya.")
        val minute = action.alarmMinute ?: 0
        val title = action.alarmTitle ?: "AI Assistant Alarm"

        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, title)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        return try {
            context.startActivity(intent)
            val formattedTime = String.format("%02d:%02d", hour, minute)
            ExecutionResult.Success("Alarm $formattedTime baje set kar diya gaya hai.")
        } catch (e: Exception) {
            ExecutionResult.Failure("Alarm set karne mein masla aya: ${e.message}")
        }
    }

    private fun executeSetTimer(action: CommandAction): ExecutionResult {
        val seconds = action.timerSeconds ?: 60
        val title = action.alarmTitle ?: "Timer"

        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            putExtra(AlarmClock.EXTRA_MESSAGE, title)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        return try {
            context.startActivity(intent)
            val minutes = seconds / 60
            val label = if (minutes > 0) "$minutes minute" else "$seconds seconds"
            ExecutionResult.Success("Timer $label ka set kar diya gaya hai.")
        } catch (e: Exception) {
            ExecutionResult.Failure("Timer set karne mein masla aya: ${e.message}")
        }
    }

    private fun executeOpenApp(action: CommandAction): ExecutionResult {
        val pkg = action.appPackage
        val appName = action.appName ?: "App"

        if (pkg != null) {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(launchIntent)
                return ExecutionResult.Success("$appName khol diya gaya hai.")
            }
        }

        // Special system shortcuts
        when (appName.lowercase()) {
            "camera", "camera kholo" -> {
                val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                return ExecutionResult.Success("Camera khol diya gaya hai.")
            }
            "settings", "settings kholo" -> {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                return ExecutionResult.Success("Settings khol di gayi hain.")
            }
        }

        return ExecutionResult.Failure("$appName app install nahi mila.")
    }

    private fun executeOpenSettings(action: CommandAction): ExecutionResult {
        val intentAction = action.settingIntentAction ?: Settings.ACTION_SETTINGS
        val intent = Intent(intentAction).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return try {
            context.startActivity(intent)
            ExecutionResult.Success("${action.summary} khol di gayi hai.")
        } catch (e: Exception) {
            ExecutionResult.Failure("Settings nahi khul sakin: ${e.message}")
        }
    }

    private fun executeAccessibilityNav(action: CommandAction): ExecutionResult {
        if (!AssistantAccessibilityService.isServiceEnabled) {
            val settingsIntent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(settingsIntent)
            return ExecutionResult.Fallback("Accessibility Service enable nahi hai. Settings kholi hain, baraye mehrbani My AI Assistant ko Accessibility mein on karein.")
        }

        val success = when (action.accessibilityActionId) {
            1 -> AssistantAccessibilityService.performHome()
            2 -> AssistantAccessibilityService.performBack()
            3 -> AssistantAccessibilityService.performRecentApps()
            4 -> AssistantAccessibilityService.performNotifications()
            5 -> AssistantAccessibilityService.performQuickSettings()
            6 -> AssistantAccessibilityService.performLockScreen()
            else -> false
        }

        return if (success) {
            ExecutionResult.Success(action.spokenResponse ?: "Action mukammal hua.")
        } else {
            ExecutionResult.Failure("Accessibility action execute nahi ho saka.")
        }
    }

    private fun executeWebSearch(action: CommandAction): ExecutionResult {
        val query = action.searchQuery ?: ""
        if (action.appName.equals("YouTube", ignoreCase = true)) {
            val intent = Intent(Intent.ACTION_SEARCH).apply {
                setPackage("com.google.android.youtube")
                putExtra("query", query)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            return try {
                context.startActivity(intent)
                ExecutionResult.Success("YouTube par '$query' search kiya ja raha hai.")
            } catch (e: Exception) {
                // Fallback to web search
                val webIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                    putExtra(SearchManager.QUERY, query)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(webIntent)
                ExecutionResult.Success("Web par search kar rahe hain: $query")
            }
        } else {
            val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra(SearchManager.QUERY, query)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            return ExecutionResult.Success("Google par '$query' search kiya ja raha hai.")
        }
    }

    private fun isPackageInstalled(packageName: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }
}
