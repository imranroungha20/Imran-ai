package com.example.engine

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream

enum class FilterPreset(val displayName: String, val description: String) {
    NONE("Original", "Natural original look"),
    CINEMATIC("Cinematic", "Deep contrast & cool teal-orange tones"),
    GOLDEN_HOUR("Golden Hour", "Warm sunset glow and enhanced highlights"),
    CYBERPUNK("Cyberpunk", "Vibrant neon blues, magentas and rich contrast"),
    VINTAGE_SEPIA("Vintage Sepia", "Classic nostalgic retro photo finish"),
    NOIR_BW("Studio Noir", "High contrast black and white portrait"),
    VIBRANT_POP("Vibrant Pop", "Enhanced colorful saturation and clarity"),
    SOFT_DREAM("Soft Dream", "Gentle pastel tones and soft highlights")
}

data class PhotoEditState(
    val brightness: Float = 0f,    // -100f to +100f
    val contrast: Float = 1f,      // 0.5f to 2.0f
    val saturation: Float = 1f,    // 0f to 2.5f
    val warmth: Float = 0f,        // -50f (cool) to +50f (warm)
    val rotation: Float = 0f,      // 0, 90, 180, 270
    val isFlipped: Boolean = false,
    val preset: FilterPreset = FilterPreset.NONE,
    val hasVignette: Boolean = false,
    val hasBossBadge: Boolean = false
)

class PhotoEditorEngine(private val context: Context) {

    suspend fun loadBitmapFromUri(uri: Uri, maxDimension: Int = 1440): Bitmap? = withContext(Dispatchers.IO) {
        try {
            var inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeStream(inputStream, null, options)
            inputStream?.close()

            var sampleSize = 1
            var width = options.outWidth
            var height = options.outHeight
            while (width / 2 >= maxDimension || height / 2 >= maxDimension) {
                width /= 2
                height /= 2
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }

            inputStream = context.contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream, null, decodeOptions)
            inputStream?.close()
            bitmap
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    suspend fun applyEdits(source: Bitmap, state: PhotoEditState): Bitmap = withContext(Dispatchers.Default) {
        var workingBitmap = source

        // 1. Rotation and Flip
        if (state.rotation != 0f || state.isFlipped) {
            val matrix = Matrix().apply {
                postRotate(state.rotation)
                if (state.isFlipped) {
                    postScale(-1f, 1f)
                }
            }
            workingBitmap = Bitmap.createBitmap(
                workingBitmap,
                0,
                0,
                workingBitmap.width,
                workingBitmap.height,
                matrix,
                true
            )
        }

        // 2. Color Adjustments via ColorMatrix
        val resultBitmap = Bitmap.createBitmap(
            workingBitmap.width,
            workingBitmap.height,
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(resultBitmap)

        val combinedMatrix = ColorMatrix()

        // Apply preset
        when (state.preset) {
            FilterPreset.NONE -> {}
            FilterPreset.CINEMATIC -> {
                // Cool shadows, warm highlights
                val cm = ColorMatrix(floatArrayOf(
                    1.1f, 0f, 0f, 0f, 10f,
                    0f, 1.05f, 0f, 0f, 5f,
                    0f, 0f, 1.25f, 0f, 20f,
                    0f, 0f, 0f, 1f, 0f
                ))
                combinedMatrix.postConcat(cm)
            }
            FilterPreset.GOLDEN_HOUR -> {
                val cm = ColorMatrix(floatArrayOf(
                    1.25f, 0f, 0f, 0f, 25f,
                    0f, 1.15f, 0f, 0f, 15f,
                    0f, 0f, 0.85f, 0f, -10f,
                    0f, 0f, 0f, 1f, 0f
                ))
                combinedMatrix.postConcat(cm)
            }
            FilterPreset.CYBERPUNK -> {
                val cm = ColorMatrix(floatArrayOf(
                    1.3f, 0f, 0f, 0f, 20f,
                    0f, 0.85f, 0f, 0f, -10f,
                    0f, 0f, 1.4f, 0f, 30f,
                    0f, 0f, 0f, 1f, 0f
                ))
                combinedMatrix.postConcat(cm)
            }
            FilterPreset.VINTAGE_SEPIA -> {
                val cm = ColorMatrix()
                cm.setSaturation(0.2f)
                val sepia = ColorMatrix(floatArrayOf(
                    0.393f, 0.769f, 0.189f, 0f, 30f,
                    0.349f, 0.686f, 0.168f, 0f, 15f,
                    0.272f, 0.534f, 0.131f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.postConcat(sepia)
                combinedMatrix.postConcat(cm)
            }
            FilterPreset.NOIR_BW -> {
                val cm = ColorMatrix()
                cm.setSaturation(0f)
                val highContrast = ColorMatrix(floatArrayOf(
                    1.35f, 0f, 0f, 0f, -30f,
                    0f, 1.35f, 0f, 0f, -30f,
                    0f, 0f, 1.35f, 0f, -30f,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.postConcat(highContrast)
                combinedMatrix.postConcat(cm)
            }
            FilterPreset.VIBRANT_POP -> {
                val cm = ColorMatrix()
                cm.setSaturation(1.5f)
                combinedMatrix.postConcat(cm)
            }
            FilterPreset.SOFT_DREAM -> {
                val cm = ColorMatrix(floatArrayOf(
                    1.05f, 0f, 0f, 0f, 15f,
                    0f, 1.05f, 0f, 0f, 15f,
                    0f, 0f, 1.15f, 0f, 20f,
                    0f, 0f, 0f, 1f, 0f
                ))
                combinedMatrix.postConcat(cm)
            }
        }

        // Apply Saturation slider
        if (state.saturation != 1f) {
            val satMatrix = ColorMatrix()
            satMatrix.setSaturation(state.saturation)
            combinedMatrix.postConcat(satMatrix)
        }

        // Apply Contrast slider
        if (state.contrast != 1f) {
            val scale = state.contrast
            val translate = (-0.5f * scale + 0.5f) * 255f
            val contrastMatrix = ColorMatrix(floatArrayOf(
                scale, 0f, 0f, 0f, translate,
                0f, scale, 0f, 0f, translate,
                0f, 0f, scale, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            ))
            combinedMatrix.postConcat(contrastMatrix)
        }

        // Apply Brightness slider
        if (state.brightness != 0f) {
            val b = state.brightness
            val brightnessMatrix = ColorMatrix(floatArrayOf(
                1f, 0f, 0f, 0f, b,
                0f, 1f, 0f, 0f, b,
                0f, 0f, 1f, 0f, b,
                0f, 0f, 0f, 1f, 0f
            ))
            combinedMatrix.postConcat(brightnessMatrix)
        }

        // Apply Warmth slider
        if (state.warmth != 0f) {
            val w = state.warmth
            val warmthMatrix = ColorMatrix(floatArrayOf(
                1f, 0f, 0f, 0f, w,
                0f, 1f, 0f, 0f, w * 0.4f,
                0f, 0f, 1f, 0f, -w,
                0f, 0f, 0f, 1f, 0f
            ))
            combinedMatrix.postConcat(warmthMatrix)
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(combinedMatrix)
        }
        canvas.drawBitmap(workingBitmap, 0f, 0f, paint)

        // 3. Optional Vignette Effect
        if (state.hasVignette) {
            val radius = Math.hypot(resultBitmap.width / 2.0, resultBitmap.height / 2.0).toFloat()
            val vignettePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    resultBitmap.width / 2f,
                    resultBitmap.height / 2f,
                    radius,
                    intArrayOf(Color.TRANSPARENT, Color.argb(160, 0, 0, 0)),
                    floatArrayOf(0.45f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(0f, 0f, resultBitmap.width.toFloat(), resultBitmap.height.toFloat(), vignettePaint)
        }

        // 4. Optional Boss Badge
        if (state.hasBossBadge) {
            val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(220, 15, 23, 42)
            }
            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#818CF8")
                textSize = (resultBitmap.width * 0.04f).coerceIn(24f, 48f)
                isFakeBoldText = true
            }
            val padding = resultBitmap.width * 0.04f
            val text = "👑 Imran AI • Boss Edition"
            val textWidth = textPaint.measureText(text)
            val rectHeight = textPaint.textSize * 1.8f

            canvas.drawRoundRect(
                padding,
                resultBitmap.height - padding - rectHeight,
                padding + textWidth + (padding * 1.5f),
                resultBitmap.height - padding,
                16f,
                16f,
                badgePaint
            )
            canvas.drawText(
                text,
                padding * 1.75f,
                resultBitmap.height - padding - (rectHeight * 0.3f),
                textPaint
            )
        }

        resultBitmap
    }

    suspend fun saveBitmapToGallery(bitmap: Bitmap, title: String = "Imran_AI_Edit"): Result<Uri> = withContext(Dispatchers.IO) {
        try {
            val filename = "${title}_${System.currentTimeMillis()}.jpg"
            var outputStream: OutputStream? = null
            var imageUri: Uri? = null

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ImranAI_Edits")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                if (imageUri != null) {
                    outputStream = resolver.openOutputStream(imageUri)
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 95, outputStream!!)
                    outputStream.close()
                    contentValues.clear()
                    contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(imageUri, contentValues, null, null)
                }
            } else {
                val imagesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                val folder = File(imagesDir, "ImranAI_Edits").apply { mkdirs() }
                val imageFile = File(folder, filename)
                outputStream = FileOutputStream(imageFile)
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, outputStream)
                outputStream.close()
                imageUri = Uri.fromFile(imageFile)
            }

            if (imageUri != null) {
                Result.success(imageUri)
            } else {
                Result.failure(Exception("Failed to save image to gallery."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun interpretVoiceEditCommand(command: String, currentState: PhotoEditState): Pair<PhotoEditState, String> {
        val lower = command.lowercase()
        var updated = currentState
        val feedback: String

        when {
            // Brightness / Light
            lower.contains("bright") || lower.contains("roshni barhao") || lower.contains("saf karo") || lower.contains("saaf karo") || lower.contains("light") -> {
                updated = updated.copy(brightness = (updated.brightness + 30f).coerceAtMost(90f), contrast = 1.15f)
                feedback = "Jee Boss, photo ki brightness aur clarity barha di hai!"
            }
            lower.contains("dark") || lower.contains("roshni kam") || lower.contains("dull") -> {
                updated = updated.copy(brightness = (updated.brightness - 30f).coerceAtLeast(-80f))
                feedback = "Jee Boss, photo ko dark aur moody look de diya hai."
            }
            // Black & White / Noir
            lower.contains("black and white") || lower.contains("b&w") || lower.contains("monochrome") || lower.contains("black white") || lower.contains("kala safed") -> {
                updated = updated.copy(preset = FilterPreset.NOIR_BW)
                feedback = "Jee Boss, classic Studio Noir Black & White look apply kar diya hai!"
            }
            // Cinematic
            lower.contains("cinematic") || lower.contains("movie") || lower.contains("film") -> {
                updated = updated.copy(preset = FilterPreset.CINEMATIC, hasVignette = true)
                feedback = "Jee Boss, movie jaisa Cinematic Teal & Orange filter apply kar diya hai!"
            }
            // Golden hour / Warm
            lower.contains("golden") || lower.contains("sunset") || lower.contains("warm") || lower.contains("dhoop") || lower.contains("amber") -> {
                updated = updated.copy(preset = FilterPreset.GOLDEN_HOUR)
                feedback = "Jee Boss, Golden Hour sunset warmth apply kar di hai!"
            }
            // Cyberpunk / Neon
            lower.contains("cyberpunk") || lower.contains("neon") || lower.contains("purple") -> {
                updated = updated.copy(preset = FilterPreset.CYBERPUNK)
                feedback = "Jee Boss, Cyberpunk neon vibrant vibes ready hain!"
            }
            // Vintage / Sepia
            lower.contains("vintage") || lower.contains("sepia") || lower.contains("purana") || lower.contains("retro") -> {
                updated = updated.copy(preset = FilterPreset.VINTAGE_SEPIA)
                feedback = "Jee Boss, vintage nostalgic retro finish apply kar di hai!"
            }
            // Colors / Saturation
            lower.contains("vibrant") || lower.contains("color") || lower.contains("rang barhao") || lower.contains("pop") -> {
                updated = updated.copy(preset = FilterPreset.VIBRANT_POP, saturation = 1.6f)
                feedback = "Jee Boss, colors aur saturation vibrant pop kar di hain!"
            }
            // Rotate
            lower.contains("rotate") || lower.contains("ghuma") || lower.contains("mod") -> {
                updated = updated.copy(rotation = (updated.rotation + 90f) % 360f)
                feedback = "Jee Boss, picture 90 degree rotate kar di hai."
            }
            // Flip
            lower.contains("flip") || lower.contains("mirror") || lower.contains("ulta") -> {
                updated = updated.copy(isFlipped = !updated.isFlipped)
                feedback = "Jee Boss, photo horizontally flip kar di hai."
            }
            // Vignette
            lower.contains("vignette") || lower.contains("corner dark") || lower.contains("edges dark") -> {
                updated = updated.copy(hasVignette = !updated.hasVignette)
                feedback = if (updated.hasVignette) "Jee Boss, vignette effect on kar diya hai!" else "Jee Boss, vignette hata diya hai."
            }
            // Boss Badge
            lower.contains("badge") || lower.contains("watermark") || lower.contains("boss") || lower.contains("tag") -> {
                updated = updated.copy(hasBossBadge = !updated.hasBossBadge)
                feedback = if (updated.hasBossBadge) "Jee Boss, 'Boss Edition' official badge add kar diya hai!" else "Jee Boss, badge remove kar diya hai."
            }
            // Reset
            lower.contains("reset") || lower.contains("original") || lower.contains("pehle jesi") -> {
                updated = PhotoEditState()
                feedback = "Jee Boss, original photo restore kar di hai!"
            }
            else -> {
                // Default enhancement: add pleasant cinematic vibrant touch
                updated = updated.copy(preset = FilterPreset.CINEMATIC, brightness = 10f, saturation = 1.2f)
                feedback = "Jee Boss, aapke hukum ke mutabiq professional AI visual enhancement apply kar di hai!"
            }
        }

        return Pair(updated, feedback)
    }
}
