package com.example.data.model

enum class ActionType {
    NONE,
    OPEN_APP,
    PHONE_CALL,
    SEND_SMS,
    WHATSAPP_MESSAGE,
    WHATSAPP_CALL,
    SET_ALARM,
    SET_TIMER,
    CREATE_REMINDER,
    OPEN_SETTINGS,
    ACCESSIBILITY_NAV,
    WEB_SEARCH,
    PHOTO_STUDIO,
    ANSWER_QUESTION,
    UNKNOWN
}

data class CommandAction(
    val type: ActionType,
    val summary: String,
    val isSensitive: Boolean = false,
    val requiresPermission: String? = null,
    val contactName: String? = null,
    val phoneNumber: String? = null,
    val messageText: String? = null,
    val appPackage: String? = null,
    val appName: String? = null,
    val alarmHour: Int? = null,
    val alarmMinute: Int? = null,
    val alarmTitle: String? = null,
    val timerSeconds: Int? = null,
    val searchQuery: String? = null,
    val settingIntentAction: String? = null,
    val accessibilityActionId: Int? = null, // e.g. AccessibilityService.GLOBAL_ACTION_HOME
    val confirmationTitle: String? = null,
    val confirmationMessage: String? = null,
    val explanationNote: String? = null,
    val spokenResponse: String? = null,
    val photoEditPrompt: String? = null
)
