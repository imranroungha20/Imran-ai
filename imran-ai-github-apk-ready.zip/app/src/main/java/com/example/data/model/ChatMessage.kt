package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val text: String,
    val isFromUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val actionType: String = "NONE",
    val actionDetails: String? = null,
    val status: String = "INFO" // INFO, SUCCESS, PENDING_CONFIRMATION, CANCELLED, REQUIRES_PERMISSION, FAILED
)
