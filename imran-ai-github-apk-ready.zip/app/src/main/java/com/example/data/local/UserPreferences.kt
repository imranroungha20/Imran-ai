package com.example.data.local

import android.content.Context
import android.content.SharedPreferences

class UserPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("ai_assistant_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_USER_PHOTO_URI = "user_photo_uri"
        private const val KEY_GEMINI_API_KEY = "gemini_api_key"
        private const val KEY_LANGUAGE = "speech_language"
        private const val KEY_TTS_ENABLED = "tts_enabled"
        private const val KEY_TTS_RATE = "tts_rate"
        private const val KEY_SETUP_COMPLETED = "setup_completed"
        private const val KEY_USER_TITLE = "user_title"
        private const val KEY_TTS_PITCH = "tts_pitch"
        private const val KEY_CONFIRM_CALLS = "confirm_calls"
        private const val KEY_CONFIRM_SMS = "confirm_sms"
        private const val KEY_CONFIRM_WHATSAPP = "confirm_whatsapp"
    }

    var userName: String
        get() = prefs.getString(KEY_USER_NAME, "Imran") ?: "Imran"
        set(value) = prefs.edit().putString(KEY_USER_NAME, value).apply()

    var userTitle: String
        get() = prefs.getString(KEY_USER_TITLE, "Boss") ?: "Boss"
        set(value) = prefs.edit().putString(KEY_USER_TITLE, value).apply()

    var userPhotoUri: String?
        get() = prefs.getString(KEY_USER_PHOTO_URI, null)
        set(value) = prefs.edit().putString(KEY_USER_PHOTO_URI, value).apply()

    var customGeminiApiKey: String
        get() = prefs.getString(KEY_GEMINI_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_GEMINI_API_KEY, value).apply()

    var speechLanguage: String
        get() = prefs.getString(KEY_LANGUAGE, "auto") ?: "auto"
        set(value) = prefs.edit().putString(KEY_LANGUAGE, value).apply()

    var isTtsEnabled: Boolean
        get() = prefs.getBoolean(KEY_TTS_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_TTS_ENABLED, value).apply()

    var ttsRate: Float
        get() = prefs.getFloat(KEY_TTS_RATE, 1.0f)
        set(value) = prefs.edit().putFloat(KEY_TTS_RATE, value).apply()

    var ttsPitch: Float
        get() = prefs.getFloat(KEY_TTS_PITCH, 1.08f)
        set(value) = prefs.edit().putFloat(KEY_TTS_PITCH, value).apply()

    var isSetupCompleted: Boolean
        get() = prefs.getBoolean(KEY_SETUP_COMPLETED, false)
        set(value) = prefs.edit().putBoolean(KEY_SETUP_COMPLETED, value).apply()

    var confirmCalls: Boolean
        get() = prefs.getBoolean(KEY_CONFIRM_CALLS, true)
        set(value) = prefs.edit().putBoolean(KEY_CONFIRM_CALLS, value).apply()

    var confirmSms: Boolean
        get() = prefs.getBoolean(KEY_CONFIRM_SMS, true)
        set(value) = prefs.edit().putBoolean(KEY_CONFIRM_SMS, value).apply()

    var confirmWhatsApp: Boolean
        get() = prefs.getBoolean(KEY_CONFIRM_WHATSAPP, true)
        set(value) = prefs.edit().putBoolean(KEY_CONFIRM_WHATSAPP, value).apply()

    var isContinuousMode: Boolean
        get() = prefs.getBoolean("continuous_mode", true)
        set(value) = prefs.edit().putBoolean("continuous_mode", value).apply()
}
