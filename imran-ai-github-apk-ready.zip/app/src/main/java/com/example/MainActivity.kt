package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.example.ui.components.ActionConfirmationDialog
import com.example.ui.components.ProfileSetupDialog
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PermissionsScreen
import com.example.ui.screens.PhotoStudioScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AssistantTab
import com.example.ui.viewmodel.AssistantViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: AssistantViewModel by viewModels()

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.toggleListening()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .safeDrawingPadding(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AssistantApp(
                        viewModel = viewModel,
                        onRequestMicPermission = {
                            val hasPerm = ContextCompat.checkSelfPermission(
                                this,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED

                            if (hasPerm) {
                                viewModel.toggleListening()
                            } else {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshAccessibilityStatus()
    }
}

@Composable
fun AssistantApp(
    viewModel: AssistantViewModel,
    onRequestMicPermission: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val messages by viewModel.chatMessages.collectAsState()

    // 1. Initial Setup Dialog (Photo & Name)
    if (uiState.showFirstLaunchSetup) {
        ProfileSetupDialog(
            initialName = uiState.userName,
            currentPhotoPath = uiState.userPhotoUri,
            onSave = { newName -> viewModel.saveUserProfile(newName) },
            onPhotoSelected = { uri -> viewModel.saveUserPhoto(uri) },
            onDismiss = { viewModel.dismissFirstLaunchSetup() }
        )
    }

    // 2. Sensitive Action Confirmation Dialog (WhatsApp, Call, SMS, Lock)
    val pendingAction = uiState.pendingConfirmation
    if (pendingAction != null) {
        ActionConfirmationDialog(
            action = pendingAction,
            onConfirm = { viewModel.confirmPendingAction() },
            onCancel = { viewModel.cancelPendingAction() }
        )
    }

    // 3. Screen Navigation
    when (uiState.currentTab) {
        AssistantTab.HOME -> {
            HomeScreen(
                uiState = uiState,
                onMicClick = onRequestMicPermission,
                onStopSpeaking = { viewModel.stopSpeaking() },
                onTextSubmit = { text -> viewModel.processUserInput(text) },
                onNavigateTab = { tab -> viewModel.setTab(tab) },
                onClearStatus = { viewModel.clearStatusBanner() },
                onToggleContinuousMode = { viewModel.toggleContinuousMode() }
            )
        }
        AssistantTab.CHAT -> {
            ChatScreen(
                uiState = uiState,
                messages = messages,
                onBack = { viewModel.setTab(AssistantTab.HOME) },
                onSendMessage = { text -> viewModel.processUserInput(text) },
                onMicClick = onRequestMicPermission,
                onStopSpeaking = { viewModel.stopSpeaking() },
                onClearHistory = { viewModel.clearChatHistory() }
            )
        }
        AssistantTab.PERMISSIONS -> {
            PermissionsScreen(
                onBack = { viewModel.setTab(AssistantTab.HOME) }
            )
        }
        AssistantTab.SETTINGS -> {
            SettingsScreen(
                uiState = uiState,
                onBack = { viewModel.setTab(AssistantTab.HOME) },
                onSaveProfile = { name -> viewModel.saveUserProfile(name) },
                onPhotoSelected = { uri -> viewModel.saveUserPhoto(uri) },
                onSaveApiKey = { key -> viewModel.saveGeminiApiKey(key) },
                onUpdateLanguage = { lang -> viewModel.updateSpeechLanguage(lang) },
                onUpdateTts = { enabled, rate -> viewModel.updateTtsSettings(enabled, rate) },
                onClearHistory = { viewModel.clearChatHistory() }
            )
        }
        AssistantTab.PHOTO_STUDIO -> {
            val app = LocalContext.current.applicationContext as AssistantApplication
            PhotoStudioScreen(
                editorEngine = app.photoEditorEngine,
                initialPrompt = uiState.photoStudioPrompt,
                isListening = uiState.isListening,
                onMicClick = onRequestMicPermission,
                onSpeakFeedback = { text -> viewModel.speakText(text) },
                onBack = { viewModel.setTab(AssistantTab.HOME) }
            )
        }
    }
}
