package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.ActionType
import com.example.engine.ContactResolver
import com.example.engine.IntentParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("My AI Assistant", appName)
  }

  @Test
  fun `test intent parser for whatsapp command`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val parser = IntentParser(ContactResolver(context))

    val result = parser.parse("WhatsApp kholo")
    assertEquals(ActionType.OPEN_APP, result.type)
    assertEquals("WhatsApp", result.appName)
  }

  @Test
  fun `test intent parser for alarm command`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val parser = IntentParser(ContactResolver(context))

    val result = parser.parse("Mera alarm 7 baje laga do")
    assertEquals(ActionType.SET_ALARM, result.type)
    assertEquals(7, result.alarmHour)
  }

  @Test
  fun `test sensitive call requires confirmation`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val parser = IntentParser(ContactResolver(context))

    val result = parser.parse("03001234567 par call karo")
    assertEquals(ActionType.PHONE_CALL, result.type)
    assertTrue(result.isSensitive)
    assertEquals("03001234567", result.phoneNumber)
  }
}
