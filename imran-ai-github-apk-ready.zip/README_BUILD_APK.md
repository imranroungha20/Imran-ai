# Imran AI — APK Build Guide

This is an Android Studio project exported from Google AI Studio and prepared for APK building.

## Build the APK

1. Extract this ZIP.
2. Open the **project root** (the folder containing `settings.gradle.kts`) in the latest Android Studio.
3. Let Android Studio finish Gradle sync and download the required SDK/dependencies.
4. Select **Build > Build APK(s)** (or **Build > Generate App Bundles or APKs > Generate APKs**, depending on your Android Studio version).
5. Install the generated debug APK on your Android phone.

The debug build is already configured with the included debug keystore, so you do **not** need a release keystore just to install/test the app.

## Gemini AI key

The app can run its local/offline intent handling without a Gemini key. For Gemini-powered answers, open the app's **Settings** screen and enter your Gemini API key there. Do not publish a real API key inside a public ZIP or APK.

## Permissions

On first use, Android may ask for microphone, contacts, phone/SMS and notification permissions. Some device-control features also require enabling the app's Accessibility Service in Android Settings. Grant only the permissions you want to use.

## Important

This package is prepared as a buildable Android Studio project, but the APK cannot be pre-compiled in this environment because the Android SDK/Gradle dependency cache is not available here.
