# GitHub se APK automatically banana

Is project mein GitHub Actions configured hai. Har push par `Build APK` workflow automatically debug APK build karega.

## GitHub par upload karne ka tareeqa

1. Is project ke **andar ki files** ko GitHub repository ke root mein upload karein. ZIP file ko repository mein rakhna zaroori nahi.
2. `main`/kisi bhi branch par push karein.
3. GitHub repository mein **Actions** tab kholen.
4. `Build APK` workflow open karein aur successful run select karein.
5. Neeche **Artifacts** mein `imran-ai-debug-apk` download karein.
6. Downloaded ZIP ko extract karke APK phone mein install karein.

Aap chahein to **Actions → Build APK → Run workflow** se manually bhi build chala sakte hain.

## Gemini API key

Real Gemini API key GitHub repository mein commit na karein. App ke andar Settings se API key configure karna preferred hai.

## Note

Ye workflow **debug APK** banata hai, jo testing/install ke liye suitable hai. Play Store ke liye alag release signing setup chahiye.
